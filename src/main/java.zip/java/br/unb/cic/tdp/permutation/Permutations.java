package br.unb.cic.tdp.permutation;public class Permutations {
}
