package br.unb.cic.tdp;

import br.unb.cic.tdp.base.CommonOperations;
import br.unb.cic.tdp.base.Configuration;
import br.unb.cic.tdp.permutation.Cycle;
import br.unb.cic.tdp.permutation.MulticyclePermutation;
import br.unb.cic.tdp.permutation.PermutationGroups;
import br.unb.cic.tdp.proof.ProofGenerator;
import br.unb.cic.tdp.util.Pair;
import lombok.SneakyThrows;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.util.StringUtils;

import java.io.File;
import java.io.FileWriter;
import java.util.*;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Stream;

import static br.unb.cic.tdp.base.CommonOperations.*;
import static br.unb.cic.tdp.permutation.PermutationGroups.computeProduct;
import static br.unb.cic.tdp.proof.ProofGenerator.renderSorting;

public class FinalPermutations {

    public static void main(String[] args) {
        Velocity.setProperty("resource.loader", "class");
        Velocity.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        Velocity.init();

        Stream.of(
                new Configuration("(0 4 2)(1 5 3)(6 10 8)(7 11 9)(12 28 14)(13 35 15)(16 20 18)(17 21 19)(29 33 31)(30 34 32)(22 26 24)(23 27 25)"),
                new Configuration("(0 4 2)(1 5 3)(6 10 8)(7 11 9)(12 16 14)(13 17 15)(18 34 32)(19 35 33)(20 24 22)(21 25 23)(26 30 28)(27 31 29)"),
                new Configuration("(0 22 20)(1 5 3)(2 6 4)(7 11 9)(8 12 10)(13 17 15)(14 18 16)(19 23 21)(24 34 26)(25 35 33)(27 31 29)(28 32 30)"),
                new Configuration("(0 4 2)(1 5 3)(6 10 8)(7 11 9)(12 22 20)(13 17 15)(14 18 16)(19 35 21)(23 27 25)(24 28 26)(29 33 31)(30 34 32)"),
                new Configuration("(0 4 2)(1 5 3)(6 10 8)(7 11 9)(12 16 14)(13 17 15)(24 34 26)(25 35 27)(28 32 30)(29 33 31)(18 22 20)(19 23 21)"),
                new Configuration("(0 4 2)(1 5 3)(6 10 8)(7 11 9)(12 28 26)(13 23 15)(14 24 16)(25 29 27)(30 34 32)(31 35 33)(17 21 19)(18 22 20)"),
                new Configuration("(0 4 2)(1 5 3)(6 16 14)(7 11 9)(8 12 10)(13 35 15)(17 21 19)(18 22 20)(23 27 25)(24 28 26)(29 33 31)(30 34 32)"),
                new Configuration("(0 10 8)(1 11 9)(2 6 4)(3 7 5)(12 16 14)(13 35 15)(17 21 19)(18 22 20)(23 27 25)(24 28 26)(29 33 31)(30 34 32)"),
                new Configuration("(0 22 20)(7 11 9)(8 12 10)(13 17 15)(14 18 16)(19 23 21)(24 34 32)(25 29 27)(26 30 28)(31 35 33)(1 5 3)(2 6 4)"),
                new Configuration("(0 4 2)(1 5 3)(6 16 8)(7 35 9)(10 14 12)(11 15 13)(17 21 19)(18 22 20)(23 27 25)(24 28 26)(29 33 31)(30 34 32)"),
                new Configuration("(0 22 2)(1 35 21)(3 19 17)(4 20 18)(5 9 7)(6 10 8)(23 27 25)(24 28 26)(29 33 31)(30 34 32)(11 15 13)(12 16 14)"),
                new Configuration("(0 4 2)(1 5 3)(6 10 8)(7 11 9)(18 34 32)(19 35 33)(20 24 22)(21 31 23)(25 29 27)(26 30 28)(12 16 14)(13 17 15)"),
                new Configuration("(0 16 14)(1 5 3)(2 6 4)(7 11 9)(8 12 10)(13 17 15)(18 34 20)(19 35 21)(22 26 24)(23 27 25)(28 32 30)(29 33 31)"),
                new Configuration("(0 4 2)(1 5 3)(6 34 8)(7 35 33)(9 13 11)(10 14 12)(15 19 17)(16 20 18)(21 25 23)(22 26 24)(27 31 29)(28 32 30)"),
                new Configuration("(0 22 2)(1 35 21)(3 19 5)(4 20 6)(7 11 9)(8 12 10)(23 27 25)(24 28 26)(29 33 31)(30 34 32)(13 17 15)(14 18 16)"),
                new Configuration("(0 4 2)(1 5 3)(12 34 14)(13 35 33)(15 19 17)(16 20 18)(21 25 23)(22 26 24)(27 31 29)(28 32 30)(6 10 8)(7 11 9)"),
                new Configuration("(0 16 14)(1 35 15)(2 6 4)(3 13 5)(17 21 19)(18 22 20)(23 27 25)(24 28 26)(29 33 31)(30 34 32)(7 11 9)(8 12 10)"),
                new Configuration("(0 16 14)(1 35 15)(2 12 4)(3 13 5)(17 21 19)(18 22 20)(23 27 25)(24 28 26)(29 33 31)(30 34 32)(6 10 8)(7 11 9)"),
                new Configuration("(0 4 2)(1 35 3)(5 9 7)(6 10 8)(11 15 13)(12 16 14)(17 21 19)(18 22 20)(23 27 25)(24 28 26)(29 33 31)(30 34 32)"),
                new Configuration("(0 4 2)(1 35 3)(5 9 7)(6 10 8)(11 15 13)(12 16 14)(17 33 19)(18 34 32)(20 30 22)(21 31 29)(23 27 25)(24 28 26)"),
                new Configuration("(0 16 2)(1 17 15)(3 7 5)(4 8 6)(18 34 20)(19 35 33)(21 25 23)(22 26 24)(27 31 29)(28 32 30)(9 13 11)(10 14 12)")
        ).forEach(conf -> sort(conf, "/home/luiskowada/proof1.333"));
    }

    @SneakyThrows
    public static void sort(final Configuration conf, String outputDir) {
        System.out.println("Sorting " + conf.getCanonical().getSpi());

        final var b = getComponents(conf.getSpi(), conf.getPi()).size();

        final var stream = generateAll0And2Moves(conf.getSpi(), conf.getPi())
                .map(Pair::getFirst)
                .map(move -> {
                    final var spi_ = computeProduct(true, conf.getPi().getMaxSymbol() + 1, conf.getSpi(), move.getInverse());
                    final var pi_ = applyTransposition(conf.getPi(), move);
                    if (getComponents(spi_, pi_).size() < b && spi_.stream().anyMatch(c -> c.size() == 5))
                        return move;
                    return null;
                }).filter(Objects::nonNull);

        final var executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        final var completionService = new ExecutorCompletionService<List<Cycle>>(executorService);

        final var submittedTasks = new ArrayList<Future<List<Cycle>>>();

        stream.forEach(m -> {
            final var move = m;
            final var _partialSorting = new Stack<Cycle>();
            _partialSorting.push(move);
            for (final var root : ProofGenerator._16_12_SPECIAL_SEQ.getChildren()) {
                submittedTasks.add(completionService.submit(() ->
                        search(PermutationGroups.computeProduct(conf.getSpi(), move.getInverse()),
                               CommonOperations.applyTransposition(conf.getPi(), move),
                               _partialSorting,
                               root)));
            }
        });

        executorService.shutdown();

        for (int i = 0; i < submittedTasks.size(); i++) {
            final var s = completionService.take();
            if (s.get().size() > 0) {
                try (final var out = new FileWriter(outputDir + "/comb/" + conf.getSpi() + ".html")) {
                    renderSorting(conf, s.get(), out);
                    System.out.println("Sorted " + conf.getSpi());
                }
                break;
            }
        }

        executorService.shutdownNow();
    }

    public static List<Cycle> search(final MulticyclePermutation spi,
                              final Cycle pi,
                              final Stack<Cycle> moves,
                              final ProofGenerator.Move root) {
        if (Thread.currentThread().isInterrupted()) {
            return Collections.emptyList();
        }

        if (moves.size() == 4) {
            if (getComponents(spi, pi).size() != 1) {
                return Collections.emptyList();
            }
        }

        Thread.currentThread().setName(Thread.currentThread().getName() + "-" + root.getMu());

        final Stream<Cycle> nextMoves;
        if (root.getMu() == 0) {
            nextMoves = generateAll0And2Moves(spi, pi)
                    .filter(p -> p.getSecond() == root.getMu())
                    .map(Pair::getFirst)
                    .map(move -> {
                        final var spi_ = computeProduct(true, pi.getMaxSymbol() + 1, spi, move.getInverse());
                        final var pi_ = applyTransposition(pi, move);
                        final var b_ = getComponents(spi_, pi_).stream().mapToInt(component -> component.stream().mapToInt(Cycle::size).sum()).max();
                        return new Pair<>(b_.getAsInt(), move);
                    }).sorted(Comparator.comparing(o -> ((Pair<Integer, Cycle>) o).getFirst()).reversed()).map(Pair::getSecond);
        } else {
            nextMoves = generateAll2Moves(spi, pi).map(Pair::getFirst);
        }

        try {
            final var iterator = nextMoves.iterator();
            while (iterator.hasNext()) {
                final var move = iterator.next();
                moves.push(move);

                if (root.getChildren().isEmpty()) {
                    return moves;
                } else {
                    for (final var m : root.getChildren()) {
                        final var spi_ = computeProduct(true, pi.getMaxSymbol() + 1, spi, move.getInverse());
                        final var pi_ = applyTransposition(pi, move);
                        final var sorting = search(spi_, pi_, moves, m);
                        if (!sorting.isEmpty()) {
                            return moves;
                        }
                    }
                }
                moves.pop();
            }
        } catch (IllegalStateException e) {
            // means empty stream
            return Collections.emptyList();
        }

        Thread.currentThread().setName(StringUtils.chop(Thread.currentThread().getName(), 2));

        return Collections.emptyList();
    }
}
